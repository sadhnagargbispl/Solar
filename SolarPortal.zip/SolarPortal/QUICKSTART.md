# 🚀 Quick Start Guide - Solar ERP System

## Installation & Running

### Prerequisites
- .NET 8 SDK installed
- SQL Server (LocalDB or Express)
- Visual Studio 2022 or VS Code

### Steps to Run

1. **Clone/Open Project**
   ```bash
   cd \\localhost\Sadhna\GitHub\Solar\SolarPortal
   ```

2. **Restore Dependencies**
   ```bash
   dotnet restore
   ```

3. **Build Solution**
   ```bash
   dotnet build
   ```

4. **Apply Database Migrations**
   ```bash
   dotnet ef database update --project SolarPortal.Infrastructure --startup-project SolarPortal.Web
   ```

5. **Run Application**
   ```bash
   cd SolarPortal.Web
   dotnet run
   ```

6. **Access Application**
   - Open browser: http://localhost:5038
   - Login with test credentials (see TESTING_GUIDE.md)

---

## 📋 Project Structure Overview

```
SolarPortal/
├── SolarPortal.Domain/          # Domain models & entities
├── SolarPortal.Application/     # Business logic & services
├── SolarPortal.Infrastructure/  # Data access & context
└── SolarPortal.Web/             # MVC UI & Controllers
    ├── Areas/
    │   ├── Admin/               # Admin panel
    │   ├── User/                # User panel
    │   ├── Installer/           # Installer panel
    │   ├── SurveyEngineer/      # Survey engineer panel
    │   └── Accountant/          # Accountant panel
    ├── Controllers/
    ├── Views/
    └── wwwroot/                 # Static files
```

---

## 🔐 Default Test Accounts

| Role | Email | Password | Area |
|------|-------|----------|------|
| Super Admin | superadmin@solarportal.com | SuperAdmin@1234 | / |
| Admin | admin@solarportal.com | Admin@1234 | /Admin |
| User | user@solarportal.com | User@1234 | /User |
| Installer | installer@solarportal.com | Installer@1234 | /Installer |
| Survey Engineer | survey@solarportal.com | Survey@1234 | /SurveyEngineer |
| Accountant | accountant@solarportal.com | Accountant@1234 | /Accountant |

---

## 📊 Pre-seeded Data

### Solar Projects
- Plan A: 1.1 kV Domestic (₹15,900)
- Plan B: 3 kV Domestic (₹19,900)
- Plan C: 5 kV Commercial (₹29,900)

### Workers
- 3 pre-configured installers/INC partners
- Ready for assignment in workflows

---

## 🎯 Main Entry Points

### User Portal
- URL: http://localhost:5038/User/Dashboard
- Create solar requests
- Track installations
- View payments
- Manage wallet

### Admin Portal
- URL: http://localhost:5038/Admin/Dashboard
- Manage users & approvals
- Payment verification
- Project management
- Reports

### Installer Portal
- URL: http://localhost:5038/Installer/Dashboard
- View assigned work
- Submit photos & reports
- Track earnings
- Request withdrawals

### Survey Engineer Portal
- URL: http://localhost:5038/SurveyEngineer/Dashboard
- View assigned surveys
- Submit site reports
- Track completion status

### Accountant Portal
- URL: http://localhost:5038/Accountant/Dashboard
- Verify payments
- Track revenue
- Manage withdrawals

---

## 📝 Recent Enhancements (Phase 1)

✅ **New Entities Added**
- SolarAccount (with auto-generated account numbers)
- PMDocument (for Surya Ghar verification)
- Wallet & WalletTransaction (with 1% TDS)
- Withdrawal (with approval workflow)
- ActivityLog (audit trail)

✅ **New Services Added**
- SolarAccountService
- PMDocumentService
- WalletService
- WithdrawalService

✅ **New Panels Created**
- Installer Dashboard
- Survey Engineer Dashboard
- Accountant Dashboard

✅ **Enhanced Registration**
- Father name field
- Aadhaar & PAN validation
- Multi-document upload support
- Admin approval workflow

---

## 🔧 Configuration Files

### appsettings.Development.json
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=SolarPortal;Trusted_Connection=true;"
  },
  "Serilog": {
    "MinimumLevel": "Information",
    "WriteTo": [
      {
        "Name": "Console"
      },
      {
        "Name": "File",
        "Args": {
          "path": "Logs/solar-portal-.txt",
          "rollingInterval": "Day"
        }
      }
    ]
  }
}
```

### Key Settings
- Database: SQL Server LocalDB
- Logging: Console + File (daily rolling)
- Session Timeout: 30 minutes
- Cookie HttpOnly: true

---

## 🛠️ Common Tasks

### Add a New Role
1. Modify `DbSeeder.cs` - add to roles array
2. Create new Area folder (e.g., `/Areas/NewRole`)
3. Create DashboardController with `[Authorize(Roles = "NewRole")]`
4. Create views in `Views/Dashboard/`

### Add a New Service
1. Create interface in `IServiceInterface.cs`
2. Create implementation `ServiceClass.cs`
3. Register in `DependencyInjection.cs`
4. Create DTOs and mappers
5. Add repository to `IUnitOfWork`

### Add Permission to Admin
1. Go to `Admin/Dashboard` or specific module
2. Use `[Authorize(Roles = "Admin")]` on controller
3. Admin gets automatic access

---

## 📊 Database Schema

**Core Tables**: 18+ tables including:
- Users (ASP.NET Identity)
- Roles & UserRoles
- SolarProjects & SolarRequests
- Payments & Documents
- SolarAccounts & PMDocuments
- Wallets & Withdrawals
- SiteSurveys, MeterDispatch, MaterialDispatch
- Installations & DCRDocuments
- Workers & Commissions
- Notifications & ActivityLogs

**All tables support**:
- Soft delete (IsDeleted flag)
- Audit columns (CreatedAt, UpdatedAt)
- Foreign key relationships
- Proper indexing

---

## 🚀 Next Steps

1. **Login with Admin Account**
   - Verify all admin panels load
   - Check dashboard widgets

2. **Create a Test User**
   - Registration page: `/Account/Register`
   - Submit with documents
   - Approve in admin panel

3. **Create a Solar Request**
   - Login as user
   - Create request
   - Upload payment
   - Wait for admin approval

4. **Verify Workflows**
   - Status timeline displays
   - Approvals function correctly
   - Roles restrict access properly

5. **Check Database**
   - Open SQL Server
   - Verify 18+ tables created
   - Check seeded data

---

## 🐛 Troubleshooting

### Database Connection Error
```
Fix: Update DefaultConnection in appsettings.json
Check: SQL Server is running
```

### Login Issues
```
Fix: Verify user exists in database
Check: Username = Email in this system
```

### Missing Views
```
Fix: Clean and rebuild solution
Check: Views folder matches controller names
```

### Role Access Denied
```
Fix: Verify user role in UserRoles table
Check: [Authorize(Roles = "RoleName")] on controller
```

---

## 📈 Performance Notes

- Application uses async/await throughout
- Entity Framework Core with lazy loading disabled
- Service layer for logic separation
- Proper error handling & validation
- Logging implemented for debugging

---

## 📞 Support

For issues:
1. Check logs: `/Logs/solar-portal-*.txt`
2. Review browser console (F12)
3. Check database connection
4. Verify Entity Framework migrations

---

## ✅ Verification Checklist

Before deployment:
- [ ] All tests pass
- [ ] Database migrations applied
- [ ] Test accounts login correctly
- [ ] All areas accessible with proper roles
- [ ] Dashboard widgets load
- [ ] Forms submit successfully
- [ ] No console errors
- [ ] Responsive design works
- [ ] Logs appear without errors
- [ ] Database tables created

---

**Version**: 1.0 - Foundation Phase
**Last Updated**: May 13, 2026
**Status**: ✅ Ready to Use
