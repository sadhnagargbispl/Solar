using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SolarPortal.Domain.Entities;

namespace SolarPortal.Infrastructure.Data;

public class DbSeeder
{
    private readonly IServiceProvider _services;

    public DbSeeder(IServiceProvider services) => _services = services;

    public async Task SeedAsync()
    {
        using var scope = _services.CreateScope();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        if (db.Database.GetPendingMigrations().Any())
            await db.Database.MigrateAsync();

        // Seed Roles
        string[] roles = { "SuperAdmin", "Admin", "User", "Installer", "SurveyEngineer", "Accountant" };
        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        // Seed Super Admin User
        const string superAdminEmail = "superadmin@solarportal.com";
        if (await userManager.FindByEmailAsync(superAdminEmail) == null)
        {
            var superAdmin = new ApplicationUser
            {
                UserName = superAdminEmail,
                Email = superAdminEmail,
                FullName = "Super Administrator",
                MobileNumber = "9999999998",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(superAdmin, "SuperAdmin@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");
        }

        // Seed Admin User
        const string adminEmail = "admin@solarportal.com";
        if (await userManager.FindByEmailAsync(adminEmail) == null)
        {
            var admin = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                FullName = "System Administrator",
                MobileNumber = "9999999999",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(admin, "Admin@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(admin, "Admin");
        }

        // Seed Installer User
        const string installerEmail = "installer@solarportal.com";
        if (await userManager.FindByEmailAsync(installerEmail) == null)
        {
            var installer = new ApplicationUser
            {
                UserName = installerEmail,
                Email = installerEmail,
                FullName = "Demo Installer",
                MobileNumber = "9800001111",
                City = "Jaipur",
                State = "Rajasthan",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(installer, "Installer@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(installer, "Installer");
        }

        // Seed Demo User
        const string userEmail = "user@solarportal.com";
        if (await userManager.FindByEmailAsync(userEmail) == null)
        {
            var user = new ApplicationUser
            {
                UserName = userEmail,
                Email = userEmail,
                FullName = "Demo User",
                MobileNumber = "9876543210",
                City = "Jaipur",
                State = "Rajasthan",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(user, "User@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(user, "User");
        }

        // Seed Survey Engineer User
        const string surveyEmail = "survey@solarportal.com";
        if (await userManager.FindByEmailAsync(surveyEmail) == null)
        {
            var survey = new ApplicationUser
            {
                UserName = surveyEmail,
                Email = surveyEmail,
                FullName = "Demo Survey Engineer",
                MobileNumber = "9800002222",
                City = "Jaipur",
                State = "Rajasthan",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(survey, "Survey@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(survey, "SurveyEngineer");
        }

        // Seed Accountant User
        const string accountantEmail = "accountant@solarportal.com";
        if (await userManager.FindByEmailAsync(accountantEmail) == null)
        {
            var accountant = new ApplicationUser
            {
                UserName = accountantEmail,
                Email = accountantEmail,
                FullName = "Demo Accountant",
                MobileNumber = "9800003333",
                City = "Jaipur",
                State = "Rajasthan",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(accountant, "Accountant@1234");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(accountant, "Accountant");
        }

        // Seed Workers
        if (!db.Workers.Any())
        {
            db.Workers.AddRange(
                new Domain.Entities.Worker { Name = "Rajan Sharma", MobileNumber = "9800001111", Specialization = "Solar Electrician", Type = Domain.Enums.WorkerType.JOB, City = "Jaipur", State = "Rajasthan", IsAvailable = true },
                new Domain.Entities.Worker { Name = "Mohan Verma", MobileNumber = "9800002222", Specialization = "Installer", Type = Domain.Enums.WorkerType.INC, City = "Jodhpur", State = "Rajasthan", IsAvailable = true },
                new Domain.Entities.Worker { Name = "Suresh Kumar", MobileNumber = "9800003333", Specialization = "Wiring Expert", Type = Domain.Enums.WorkerType.JOB, City = "Udaipur", State = "Rajasthan", IsAvailable = true }
            );
            await db.SaveChangesAsync();
        }

        // Seed Solar Projects (master)
        if (!db.SolarProjects.Any())
        {
            db.SolarProjects.AddRange(
                new Domain.Entities.SolarProject {
                    Name = "Plan A — 1.1 kV Domestic",
                    SolarTypeKV = 1.1m, ConnectionType = Domain.Enums.ConnectionType.Domestic,
                    BV = 100, FinalBV = 110,
                    DiscomWork = 1500, DealClose = 1500, SCZMenue = 3000, SportainTeam = 3000,
                    TotalAmount = 15900, IsActive = true
                },
                new Domain.Entities.SolarProject {
                    Name = "Plan B — 3 kV Domestic",
                    SolarTypeKV = 3m, ConnectionType = Domain.Enums.ConnectionType.Domestic,
                    BV = 100, FinalBV = 175,
                    DiscomWork = 2500, DealClose = 2500, SCZMenue = 4500, SportainTeam = 4500,
                    TotalAmount = 19900, IsActive = true
                },
                new Domain.Entities.SolarProject {
                    Name = "Plan C — 5 kV Commercial",
                    SolarTypeKV = 5m, ConnectionType = Domain.Enums.ConnectionType.Commercial,
                    BV = 100, FinalBV = 175,
                    DiscomWork = 5000, DealClose = 5000, SCZMenue = 8000, SportainTeam = 8000,
                    TotalAmount = 29900, IsActive = true
                }
            );
            await db.SaveChangesAsync();
        }
    }
}