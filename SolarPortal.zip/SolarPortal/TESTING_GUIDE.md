# Solar ERP System - Testing & Access Guide

## 🌐 Application URL

**Live Application**: http://localhost:5038

---

## 🔑 Test Accounts & Credentials

### 1. Super Admin Panel
```
Email:    superadmin@solarportal.com
Password: SuperAdmin@1234
URL:      http://localhost:5038/Account/Login
Role:     Full system access
```
**Features Available**:
- Manage all admins
- System settings
- Global reports
- User management
- All approvals

### 2. Admin Panel
```
Email:    admin@solarportal.com
Password: Admin@1234
URL:      http://localhost:5038/Account/Login
Role:     Administrative access
```
**Features Available**:
- User approval/rejection
- Payment verification
- PM Surya Ghar verification
- Dispatch management
- Report generation

### 3. User Panel
```
Email:    user@solarportal.com
Password: User@1234
URL:      http://localhost:5038/Account/Login
Role:     End user access
```
**Features Available**:
- View dashboard
- Create solar requests
- Upload payments
- Track installation status
- Access wallet
- View notifications

### 4. Installer Panel
```
Email:    installer@solarportal.com
Password: Installer@1234
URL:      http://localhost:5038/Installer/Dashboard
Role:     Installation worker
```
**Features Available**:
- View pending installations
- Upload work photos
- Submit reports
- Track earnings
- View wallet balance

### 5. Survey Engineer Panel
```
Email:    survey@solarportal.com
Password: Survey@1234
URL:      http://localhost:5038/SurveyEngineer/Dashboard
Role:     Site survey specialist
```
**Features Available**:
- View assigned surveys
- Upload site photos
- Submit survey reports
- Add remarks
- View pending approvals

### 6. Accountant Panel
```
Email:    accountant@solarportal.com
Password: Accountant@1234
URL:      http://localhost:5038/Accountant/Dashboard
Role:     Financial management
```
**Features Available**:
- View pending payments
- Verify transactions
- Track revenue
- Manage withdrawals
- Generate financial reports

---

## 🧪 Testing Scenarios

### Scenario 1: User Registration & Admin Approval
1. Navigate to: http://localhost:5038/Account/Register
2. Fill registration form with:
   - Name: Test User
   - Father Name: Test Father
   - Email: testuser@example.com
   - Mobile: 9876543210
   - Aadhaar: 123456789012
   - PAN: ABCDE1234F
   - Address: Test Address
   - City: Bangalore
   - State: Karnataka
   - Pincode: 560001
   - Password: TestUser@123
3. Upload documents (Aadhaar, PAN, Bank Passbook, etc.)
4. Submit form
5. Expected: User created with "Pending" status
6. Admin approval required

### Scenario 2: Solar Request Creation
1. Login as User: user@solarportal.com
2. Navigate to: User → Solar Connection Request
3. Select Solar Project (Plan A: 15,900 or Plan B: 19,900)
4. Select Connection Type:
   - Domestic (allows DCR)
   - Commercial (skips DCR)
5. Enter payment details:
   - Amount
   - UTR Number
   - Payment Date
   - Upload screenshot
6. Generate Request Number
7. Submit for admin approval

### Scenario 3: Payment Verification (Admin)
1. Login as Admin: admin@solarportal.com
2. Navigate to: Admin → Payment Verification
3. View pending payments
4. Verify payment details
5. Approve/Reject with remarks
6. System updates solar account status

### Scenario 4: Site Survey Assignment
1. Admin assigns survey to Engineer
2. Engineer views pending surveys
3. Engineer visits site and uploads:
   - Photos
   - Survey report
   - Remarks
4. Admin reviews and approves
5. Status progresses to "Completed"

### Scenario 5: Installation Workflow
1. Material dispatch to installer
2. Installer logs in and accepts work
3. Uploads before/after photos
4. Submits installation report
5. Admin approves completion
6. System updates project status

### Scenario 6: Wallet & Commission
1. Installation completion generates commission
2. 1% TDS automatically deducted
3. Income reflected in Installer wallet
4. Installer can request withdrawal
5. Admin approves/rejects withdrawal request
6. Withdrawal amount credited

---

## 📊 Pre-seeded Data

### Solar Projects
```
1. Plan A - 1.1 kV Domestic
   Price: ₹15,900
   Status: Active

2. Plan B - 3 kV Domestic
   Price: ₹19,900
   Status: Active

3. Plan C - 5 kV Commercial
   Price: ₹29,900
   Status: Active
```

### Workers (Installers/INC)
```
1. Rajan Sharma
   Type: JOB (Employee)
   Specialization: Solar Electrician
   Location: Jaipur, Rajasthan
   Status: Available

2. Mohan Verma
   Type: INC (Self-employed)
   Specialization: Installer
   Location: Jodhpur, Rajasthan
   Status: Available

3. Suresh Kumar
   Type: JOB (Employee)
   Specialization: Wiring Expert
   Location: Udaipur, Rajasthan
   Status: Available
```

---

## 🔍 Key Features to Test

### 1. Authentication
- [ ] Login with correct credentials - should succeed
- [ ] Login with wrong password - should fail
- [ ] Try to access admin panel as user - should deny
- [ ] Session timeout after 30 minutes
- [ ] Logout functionality

### 2. Role-Based Access
- [ ] Installer can only access Installer/Dashboard
- [ ] Survey Engineer can only access SurveyEngineer/Dashboard
- [ ] User cannot access Admin panel
- [ ] Admin cannot access restricted user features

### 3. Registration Module
- [ ] All required fields validated
- [ ] Email uniqueness validation
- [ ] Mobile number uniqueness validation
- [ ] Password strength validation
- [ ] Document upload file type validation
- [ ] Documents reject non-PDF/JPG/PNG files

### 4. Workflow Progression
- [ ] Status timeline updates correctly
- [ ] Project moves from Registration → Product Selection → PM Surya Ghar → Meter Dispatch → Site Survey → Material Dispatch → Installation → DCR → Completed
- [ ] Commercial projects skip DCR
- [ ] Status badges show correctly

### 5. Approvals
- [ ] Admin can approve registrations
- [ ] Admin can approve payments
- [ ] Admin can approve site surveys
- [ ] Admin can approve installations
- [ ] Remarks can be added to approvals
- [ ] Rejection with reason works

### 6. Notifications
- [ ] Users receive notifications on status changes
- [ ] In-app notifications display correctly
- [ ] Notification count updates

### 7. Wallet System
- [ ] Wallet created on account generation
- [ ] Commission calculated correctly
- [ ] 1% TDS deducted automatically
- [ ] Withdrawal requests show correct pending balance
- [ ] Approved withdrawals update wallet

---

## 🎯 Dashboard Elements to Verify

### User Dashboard
- [ ] Total requests card
- [ ] Pending approvals card
- [ ] Active installations card
- [ ] Pending payments card
- [ ] Recent requests list
- [ ] Status timeline visible

### Admin Dashboard
- [ ] Total users card
- [ ] Pending approvals card
- [ ] Active installations card
- [ ] Pending payments card
- [ ] Revenue display
- [ ] Recent activities list

### Installer Dashboard
- [ ] Pending installations card
- [ ] Completed today card
- [ ] Total earnings card
- [ ] Pending payments card
- [ ] Recent work list

### Survey Engineer Dashboard
- [ ] Pending surveys card
- [ ] Completed today card
- [ ] Total surveys card
- [ ] Pending approvals card
- [ ] Recent surveys list

### Accountant Dashboard
- [ ] Pending payments card
- [ ] Verified today card
- [ ] Total revenue card
- [ ] Pending withdrawals card
- [ ] Recent transactions list

---

## 🛠️ Database Info

**Server**: LocalDB or SQL Server
**Database**: SolarPortal
**Tables**: 18+ tables with relationships
**Migrations**: Auto-applied on app startup
**Connection String**: Check appsettings.Development.json

---

## 📱 Responsive Design Testing

Test on different viewport sizes:
- [ ] Desktop (1920x1080)
- [ ] Tablet (768x1024)
- [ ] Mobile (375x667)
- [ ] Mobile Landscape (667x375)

All pages should respond correctly with Bootstrap 5.

---

## 🔒 Security Checklist

- [ ] Passwords are hashed
- [ ] SQL injection protection (EF Core parameterized queries)
- [ ] CSRF tokens on forms
- [ ] Authorization checks on all controllers
- [ ] Roles validated for access control
- [ ] Sensitive data not exposed in logs

---

## 📈 Performance Monitoring

Monitor these metrics:
- Page load time (target: <2 seconds)
- Database query performance
- Memory usage
- CPU utilization
- Connection pool status

---

## 🐛 Common Test Cases

### Positive Tests
1. Valid registration with all documents
2. Successful payment verification
3. Status progression through workflow
4. Approval with remarks
5. Commission calculation

### Negative Tests
1. Duplicate email registration
2. Invalid Aadhaar/PAN format
3. Rejecting payment verification
4. Missing required documents
5. Insufficient balance for withdrawal

### Edge Cases
1. Max file upload size
2. Concurrent requests
3. Rapid status changes
4. Bulk user creation
5. Date boundary conditions

---

## 📞 Support & Debugging

If issues occur:
1. Check browser console for JavaScript errors (F12)
2. Check application logs in: `/Logs/solar-portal-*.txt`
3. Verify database connection in SQL Server
4. Check Entity Framework migrations
5. Verify user roles in database

---

## ⚡ Performance Tips

- Use browser DevTools for performance profiling
- Monitor network tab for slow requests
- Check Application tab for session data
- Review Console for warnings

---

**Last Updated**: May 13, 2026
**Version**: 1.0
**Status**: Ready for Testing
