using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SolarPortal.Web.Areas.Accountant.Controllers;

[Area("Accountant")]
[Authorize(Roles = "Accountant")]
public class DashboardController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}