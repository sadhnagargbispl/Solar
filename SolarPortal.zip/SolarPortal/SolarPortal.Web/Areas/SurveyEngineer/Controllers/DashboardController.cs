using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SolarPortal.Web.Areas.SurveyEngineer.Controllers;

[Area("SurveyEngineer")]
[Authorize(Roles = "SurveyEngineer")]
public class DashboardController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}