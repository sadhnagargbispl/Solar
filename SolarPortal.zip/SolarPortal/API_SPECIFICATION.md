# Solar ERP System - API Specification (Phase 2)

## Overview

This document outlines the REST API endpoints that need to be implemented for the Solar ERP system to support mobile apps, third-party integrations, and advanced frontend frameworks.

---

## Authentication API

### POST /api/auth/login
**Description**: User login with email and password
**Request**:
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```
**Response** (200 OK):
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "refresh_token_value",
  "expiresIn": 3600,
  "user": {
    "id": "user-id",
    "email": "user@example.com",
    "fullName": "John Doe",
    "roles": ["User"]
  }
}
```

### POST /api/auth/register
**Description**: User registration
**Request**:
```json
{
  "fullName": "John Doe",
  "fatherName": "Father Name",
  "email": "john@example.com",
  "mobileNumber": "9876543210",
  "password": "SecurePassword123",
  "aadhaarNumber": "123456789012",
  "panNumber": "ABCDE1234F",
  "address": "123 Main St",
  "city": "Bangalore",
  "state": "Karnataka",
  "pinCode": "560001"
}
```
**Response** (201 Created):
```json
{
  "id": "new-user-id",
  "email": "john@example.com",
  "status": "Pending",
  "message": "Registration successful. Please wait for admin approval."
}
```

### POST /api/auth/refresh
**Description**: Refresh access token
**Request**:
```json
{
  "refreshToken": "refresh_token_value"
}
```
**Response** (200 OK):
```json
{
  "token": "new_access_token",
  "expiresIn": 3600
}
```

---

## Solar Request API

### GET /api/requests
**Description**: Get all solar requests (with pagination)
**Parameters**:
- `pageNumber` (optional, default: 1)
- `pageSize` (optional, default: 10)
- `status` (optional)
- `userId` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "requestNumber": "SCR-001",
      "userId": "user-id",
      "solarProjectId": 1,
      "connectionType": "Domestic",
      "planAmount": 15900.00,
      "currentStage": "ProductSelection",
      "approvalStatus": "Pending",
      "createdAt": "2026-05-13T10:30:00Z"
    }
  ],
  "pageNumber": 1,
  "pageSize": 10,
  "totalRecords": 50,
  "totalPages": 5
}
```

### GET /api/requests/{id}
**Description**: Get single request details
**Response** (200 OK):
```json
{
  "id": 1,
  "requestNumber": "SCR-001",
  "userId": "user-id",
  "solarProjectId": 1,
  "connectionType": "Domestic",
  "planAmount": 15900.00,
  "currentStage": "ProductSelection",
  "approvalStatus": "Pending",
  "documents": [
    {
      "id": 1,
      "documentType": "AadharCard",
      "fileName": "aadhar.pdf",
      "status": "Approved"
    }
  ],
  "payments": [
    {
      "id": 1,
      "amount": 15900.00,
      "status": "Pending",
      "transactionId": "UTR123456"
    }
  ]
}
```

### POST /api/requests
**Description**: Create new solar request
**Request**:
```json
{
  "solarProjectId": 1,
  "connectionType": "Domestic",
  "requestType": "WithActivation"
}
```
**Response** (201 Created):
```json
{
  "id": 1,
  "requestNumber": "SCR-001",
  "status": "Registration",
  "message": "Request created successfully"
}
```

### PUT /api/requests/{id}
**Description**: Update solar request
**Request**:
```json
{
  "planAmount": 15900.00,
  "connectionType": "Domestic"
}
```
**Response** (200 OK):
```json
{
  "id": 1,
  "success": true,
  "message": "Request updated successfully"
}
```

---

## Solar Account API

### GET /api/accounts
**Description**: Get user's solar accounts
**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "accountNumber": "SA-0001",
      "solarRequestId": 1,
      "projectAmount": 15900.00,
      "depositAmount": 5000.00,
      "dueAmount": 10900.00,
      "currentStatus": "MeterDispatch",
      "isFrozen": false,
      "createdAt": "2026-05-13T10:30:00Z"
    }
  ]
}
```

### GET /api/accounts/{id}
**Description**: Get account details with full history
**Response** (200 OK):
```json
{
  "id": 1,
  "accountNumber": "SA-0001",
  "projectAmount": 15900.00,
  "paymentHistory": [
    {
      "date": "2026-05-10T00:00:00Z",
      "amount": 5000.00,
      "status": "Verified",
      "transactionId": "UTR123456"
    }
  ],
  "currentStatus": "MeterDispatch",
  "timeline": [
    { "status": "Registration", "completedAt": "2026-05-01T00:00:00Z" },
    { "status": "ProductSelection", "completedAt": "2026-05-05T00:00:00Z" }
  ]
}
```

### POST /api/accounts/{id}/freeze
**Description**: Freeze account (Admin only)
**Request**:
```json
{
  "reason": "Non-payment"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Account frozen successfully"
}
```

---

## Payment API

### GET /api/payments
**Description**: Get all payments
**Parameters**:
- `status` (optional: "Pending", "Verified", "Rejected")
- `solarRequestId` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "transactionId": "UTR123456",
      "amount": 5000.00,
      "paymentDate": "2026-05-10T00:00:00Z",
      "status": "Pending",
      "verificationStatus": "Pending",
      "remarks": null
    }
  ]
}
```

### POST /api/payments
**Description**: Upload payment proof
**Request** (form-data):
```
amount: 5000.00
transactionId: UTR123456
paymentDate: 2026-05-10
paymentScreenshot: [file]
```
**Response** (201 Created):
```json
{
  "id": 1,
  "transactionId": "UTR123456",
  "status": "Pending Verification",
  "message": "Payment uploaded successfully"
}
```

### PUT /api/payments/{id}/approve
**Description**: Approve payment (Admin only)
**Request**:
```json
{
  "remarks": "Payment verified"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Payment approved",
  "updatedStatus": "Verified"
}
```

### PUT /api/payments/{id}/reject
**Description**: Reject payment (Admin only)
**Request**:
```json
{
  "remarks": "Invalid transaction ID"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Payment rejected"
}
```

---

## Document API

### GET /api/documents/{requestId}
**Description**: Get all documents for a request
**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "documentType": "AadharCard",
      "fileName": "aadhar.pdf",
      "fileSize": 2048,
      "status": "Approved",
      "uploadedAt": "2026-05-13T10:30:00Z"
    }
  ]
}
```

### POST /api/documents/upload
**Description**: Upload document (form-data)
**Request**:
```
requestId: 1
documentType: "AadharCard"
file: [file]
```
**Response** (201 Created):
```json
{
  "id": 1,
  "documentType": "AadharCard",
  "fileName": "aadhar.pdf",
  "status": "Pending",
  "message": "Document uploaded successfully"
}
```

---

## PM Surya Ghar API

### POST /api/pm-documents/upload
**Description**: Upload PM Surya Ghar document
**Request** (form-data):
```
solarRequestId: 1
documentType: "Aadhaar"
file: [file]
```
**Response** (201 Created):
```json
{
  "id": 1,
  "documentType": "Aadhaar",
  "status": "Pending",
  "message": "Document uploaded for verification"
}
```

### GET /api/pm-documents/{requestId}
**Description**: Get all PM documents for request
**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "documentType": "Aadhaar",
      "status": "Approved",
      "uploadedAt": "2026-05-13T10:30:00Z",
      "verifiedAt": "2026-05-13T15:00:00Z"
    }
  ]
}
```

### PUT /api/pm-documents/{id}/approve
**Description**: Approve PM document (Admin only)
**Request**:
```json
{
  "remarks": "Verified successfully"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Document approved"
}
```

---

## Site Survey API

### GET /api/surveys
**Description**: Get surveys with filters
**Parameters**:
- `status` (optional)
- `engineerId` (optional)
- `state` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "solarRequestId": 1,
      "engineerId": "engineer-id",
      "surveyDate": "2026-05-15T00:00:00Z",
      "status": "InProgress",
      "location": {
        "city": "Bangalore",
        "state": "Karnataka"
      }
    }
  ]
}
```

### POST /api/surveys
**Description**: Create survey assignment (Admin only)
**Request**:
```json
{
  "solarRequestId": 1,
  "engineerId": "engineer-id",
  "scheduledDate": "2026-05-15T00:00:00Z"
}
```
**Response** (201 Created):
```json
{
  "id": 1,
  "status": "Pending",
  "message": "Survey assigned successfully"
}
```

### POST /api/surveys/{id}/submit
**Description**: Submit survey results (Engineer only)
**Request** (form-data):
```
surveyDate: 2026-05-15
report: [file]
photos: [files...]
remarks: "Site suitable for installation"
```
**Response** (200 OK):
```json
{
  "id": 1,
  "status": "Completed",
  "message": "Survey submitted for approval"
}
```

---

## Meter Dispatch API

### GET /api/meter-dispatch
**Description**: Get meter dispatches
**Parameters**:
- `status` (optional: "Pending", "Dispatched", "Delivered", "Installed")
- `state` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "meterNumber": "METER-001",
      "dispatchDate": "2026-05-15T00:00:00Z",
      "courierName": "FedEx",
      "status": "Dispatched",
      "trackingNumber": "TRK123456"
    }
  ]
}
```

### POST /api/meter-dispatch
**Description**: Create meter dispatch (Admin only)
**Request**:
```json
{
  "meterNumber": "METER-001",
  "solarRequestId": 1,
  "courierName": "FedEx",
  "trackingNumber": "TRK123456",
  "dispatchDate": "2026-05-15T00:00:00Z"
}
```
**Response** (201 Created):
```json
{
  "id": 1,
  "status": "Pending",
  "message": "Meter dispatch created"
}
```

---

## Installation API

### GET /api/installations
**Description**: Get installations with filters
**Parameters**:
- `status` (optional)
- `installerId` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "solarRequestId": 1,
      "installerId": "installer-id",
      "status": "Started",
      "assignedDate": "2026-05-13T00:00:00Z"
    }
  ]
}
```

### POST /api/installations/{id}/accept
**Description**: Accept installation work (Installer only)
**Request**:
```json
{
  "acceptanceDate": "2026-05-13T10:30:00Z"
}
```
**Response** (200 OK):
```json
{
  "id": 1,
  "status": "Accepted",
  "message": "Installation work accepted"
}
```

### POST /api/installations/{id}/submit
**Description**: Submit installation report (Installer only)
**Request** (form-data):
```
beforePhotos: [files...]
afterPhotos: [files...]
report: [file]
completionDate: 2026-05-18
remarks: "Installation completed successfully"
```
**Response** (200 OK):
```json
{
  "id": 1,
  "status": "Completed",
  "message": "Installation report submitted for approval"
}
```

---

## DCR API

### GET /api/dcr/{requestId}
**Description**: Get DCR records (only for domestic)
**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "date": "2026-05-20T00:00:00Z",
      "reading": 1234.5,
      "remarks": "Daily reading recorded",
      "status": "Recorded"
    }
  ]
}
```

### POST /api/dcr
**Description**: Record daily reading (Installer only)
**Request**:
```json
{
  "requestId": 1,
  "date": "2026-05-20T00:00:00Z",
  "reading": 1234.5,
  "remarks": "Daily reading"
}
```
**Response** (201 Created):
```json
{
  "id": 1,
  "status": "Recorded",
  "message": "DCR entry recorded successfully"
}
```

---

## Wallet API

### GET /api/wallet
**Description**: Get user's wallet information
**Response** (200 OK):
```json
{
  "id": 1,
  "userId": "user-id",
  "totalIncome": 50000.00,
  "tds": 500.00,
  "netAmount": 49500.00,
  "withdrawnAmount": 10000.00,
  "pendingBalance": 39500.00
}
```

### GET /api/wallet/transactions
**Description**: Get wallet transaction history
**Parameters**:
- `pageNumber` (optional)
- `pageSize` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "transactionType": "Income",
      "amount": 5000.00,
      "description": "Commission for Installation SCR-001",
      "transactionDate": "2026-05-18T00:00:00Z"
    }
  ],
  "totalRecords": 25
}
```

---

## Withdrawal API

### POST /api/withdrawals
**Description**: Request withdrawal
**Request**:
```json
{
  "amount": 10000.00
}
```
**Response** (201 Created):
```json
{
  "id": 1,
  "amount": 10000.00,
  "status": "Pending",
  "message": "Withdrawal request submitted"
}
```

### GET /api/withdrawals
**Description**: Get withdrawal requests
**Parameters**:
- `status` (optional)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "amount": 10000.00,
      "status": "Pending",
      "requestedDate": "2026-05-13T10:30:00Z"
    }
  ]
}
```

### PUT /api/withdrawals/{id}/approve
**Description**: Approve withdrawal (Admin only)
**Request**:
```json
{
  "remarks": "Approved for processing"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Withdrawal approved"
}
```

---

## Dashboard API

### GET /api/dashboard/admin/summary
**Description**: Get admin dashboard summary
**Response** (200 OK):
```json
{
  "totalUsers": 150,
  "pendingApprovals": 12,
  "activeInstallations": 25,
  "pendingPayments": 8,
  "totalRevenue": 500000.00,
  "monthlyRevenue": 45000.00
}
```

### GET /api/dashboard/user/summary
**Description**: Get user dashboard summary
**Response** (200 OK):
```json
{
  "totalRequests": 3,
  "pendingApprovals": 1,
  "activeInstallations": 1,
  "pendingPayments": 1,
  "walletBalance": 5000.00
}
```

---

## Report API

### GET /api/reports/users
**Description**: Generate user report
**Parameters**:
- `startDate` (optional)
- `endDate` (optional)
- `format` ("PDF" | "Excel" | "CSV")

**Response**: File download

### GET /api/reports/payments
**Description**: Generate payment report
**Parameters**:
- `status` (optional)
- `format` ("PDF" | "Excel" | "CSV")

**Response**: File download

### GET /api/reports/installations
**Description**: Generate installation report
**Parameters**:
- `state` (optional)
- `format` ("PDF" | "Excel" | "CSV")

**Response**: File download

---

## Notification API

### GET /api/notifications
**Description**: Get user notifications
**Parameters**:
- `unreadOnly` (optional, default: false)

**Response** (200 OK):
```json
{
  "data": [
    {
      "id": 1,
      "title": "Payment Approved",
      "message": "Your payment of ₹5000 has been approved",
      "type": "Success",
      "isRead": false,
      "createdAt": "2026-05-13T10:30:00Z"
    }
  ],
  "unreadCount": 3
}
```

### PUT /api/notifications/{id}/read
**Description**: Mark notification as read
**Response** (200 OK):
```json
{
  "success": true
}
```

---

## Settings API

### GET /api/settings/profile
**Description**: Get user profile settings
**Response** (200 OK):
```json
{
  "fullName": "John Doe",
  "email": "john@example.com",
  "mobileNumber": "9876543210",
  "address": "123 Main St",
  "city": "Bangalore",
  "state": "Karnataka"
}
```

### PUT /api/settings/profile
**Description**: Update profile
**Request**:
```json
{
  "fullName": "John Doe",
  "mobileNumber": "9876543210",
  "address": "New Address"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Profile updated successfully"
}
```

### PUT /api/settings/password
**Description**: Change password
**Request**:
```json
{
  "currentPassword": "old_password",
  "newPassword": "new_password"
}
```
**Response** (200 OK):
```json
{
  "success": true,
  "message": "Password changed successfully"
}
```

---

## Error Responses

All APIs follow standard error response format:

### 400 Bad Request
```json
{
  "statusCode": 400,
  "message": "Invalid input",
  "errors": {
    "email": ["Email is required"]
  }
}
```

### 401 Unauthorized
```json
{
  "statusCode": 401,
  "message": "Unauthorized access"
}
```

### 403 Forbidden
```json
{
  "statusCode": 403,
  "message": "Access denied. You don't have permission"
}
```

### 404 Not Found
```json
{
  "statusCode": 404,
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "statusCode": 500,
  "message": "An error occurred processing your request"
}
```

---

## Authentication Headers

All protected endpoints require:
```
Authorization: Bearer <access_token>
Content-Type: application/json
```

---

## Rate Limiting

- 100 requests per minute per IP
- 1000 requests per hour per user
- Returns 429 Too Many Requests

---

## Pagination

List endpoints support pagination:
- `pageNumber` (default: 1)
- `pageSize` (default: 10, max: 100)

Response includes:
- `data`: Array of records
- `pageNumber`: Current page
- `pageSize`: Records per page
- `totalRecords`: Total count
- `totalPages`: Total pages

---

**Version**: 1.0
**Last Updated**: May 13, 2026
**Status**: Specification Ready for Implementation
